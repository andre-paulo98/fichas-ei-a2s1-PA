
**** "instalar" tags para geany  ***

Descompactar ficheiro "geany-tags.tar.bz2" para:
~/.config/geany



*** exemplo da listagem da pasta ~/.config/geany ap�s instala��o ***
$ ls  ~/.config/geany/
filedefs
geany_socket_ubuntu__0  
tags
geany.conf  
keybindings.conf        
templates


